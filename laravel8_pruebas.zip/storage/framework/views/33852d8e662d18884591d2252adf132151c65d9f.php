<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <title>Pruebas</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <h1 class="mt-4 mb-4">Listado de mascotas</h1>
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Color de pelo</th>
                    <th>Estado</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($mascota->id_mascota); ?></td>
                            <td><?php echo e($mascota->nombre_mascota); ?></td>
                            <td><?php echo e($mascota->color_pelo); ?></td>
                            <td><?php echo e($mascota->esterilizado); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="row">
                <?php echo e($mascotas->links()); ?>

            </div>
        </div>
    </div>
    
    <script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
</body>
</html><?php /**PATH D:\DESARROLLO\DESARROLLO WEB\Laravel\laravel8_pruebas\resources\views/inicio.blade.php ENDPATH**/ ?>